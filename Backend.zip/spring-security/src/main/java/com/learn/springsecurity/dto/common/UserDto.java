package com.learn.springsecurity.dto.common;

import com.learn.springsecurity.enumerated.Role;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class UserDto {

    private Long id;
    private String name;
    private String email;
    private String password;
    private Role role;
    private String age;
    
    private String mobileNo;
    
    private String dateOfBirth;
    
    private String gender;
    
    private String maritalStatus;
    
    private String addressLine1;
    
    private String addressLine2;
    
    private String city;

    private String state;
    
    private String nationality;
    
    private String country;

    private String pincode;
}