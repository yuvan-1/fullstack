package com.learn.springsecurity.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegisterRequest {
    @NonNull
    private String name;

    @NonNull
    private String email;

    @NonNull
    private String password;

    @NonNull
    private String role;
}


// dto - They simplify the process of moving data by combining multiple data elements into a single object, thereby reducing the number of calls that need to be made between client and server or between different application layers.

//Unlike domain models that contain data along with business logic, DTOs are typically anemic models, meaning they contain only data and no business logic. This makes them lightweight and ideal for data transfer.

//n applications with a layered architecture (e.g., presentation, business, data access layers), DTOs can be used to transfer data between these layers,