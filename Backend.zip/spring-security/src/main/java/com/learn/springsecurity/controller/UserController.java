package com.learn.springsecurity.controller;

import static com.learn.springsecurity.utils.MyConstant.*;

import java.security.Principal;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learn.springsecurity.dto.common.UserDto;
import com.learn.springsecurity.dto.request.PasswordRequest;
import com.learn.springsecurity.service.UserService;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


@CrossOrigin(origins = "http://localhost:5175/")

@RestController // every method return a domain object . It's shorthand for including both
                // @Controller and @ResponseBody.

@RequestMapping(USER) // base URI

@PreAuthorize("hasAnyRole('USER', 'ADMIN')") // only 'USER' or 'ADMIN' roles can access the methods in this controller.

@Tag(name = "USER") // A Swagger/OpenAPI annotation that groups all the controller's endpoints under
                    // the "USER" tag in the generated API documentation.

@RequiredArgsConstructor // A Lombok annotation that generates a constructor with one parameter for each
                         // field that is final. This is used for dependency injection of the
                         // UserService.

public class UserController {

    private final UserService userService; // final keyword indicates that this dependency must be initialized during
                                           // the construction of UserController, which Spring handles automatically due
                                           // to the @RequiredArgsConstructor annotation.

    @GetMapping
    @PreAuthorize("hasAnyAuthority('user:read', 'admin:read')")
    public String get() {
        return "GET:: user controller";
    }

    @PatchMapping(FORGOT_PASSWORD)
    @PreAuthorize("hasAnyAuthority('user:update', 'admin:update')")
    @Hidden // This annotation from Swagger/OpenAPI suggests that this endpoint should be
    // omitted from the generated API documentation, perhaps for security reasons or
    // because it's not intended to be publicly documented.
    public ResponseEntity<?> forgotPassword(PasswordRequest request, Principal principal) {
        userService.forgotPassword(request, principal);
        return ResponseEntity.ok().body("Password changed successfully");
    }
    
    
    @GetMapping("/details")
    @PreAuthorize("hasAnyAuthority('user:read', 'admin:read')")
    public ResponseEntity<?> getUserDetails(Principal principal)
    {
        UserDto userDetailDto = userService.getUserDetailsByEmail(principal.getName());
        return new ResponseEntity<>(userDetailDto,HttpStatus.OK);
    }
    
}
