package com.learn.springsecurity.service.impl;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.learn.springsecurity.dto.common.UserDto;
import com.learn.springsecurity.dto.request.PasswordRequest;
import com.learn.springsecurity.dto.response.RegisterResponse;
import com.learn.springsecurity.exception.UserNotFoundException;
import com.learn.springsecurity.model.User;
import com.learn.springsecurity.repository.UserRepository;
import com.learn.springsecurity.service.UserService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final PasswordEncoder passwordEncoder;

    @Autowired
    private UserRepository userRepository;

    @Override
    public void forgotPassword(PasswordRequest request, Principal principal) {
        var user = (User) ((UsernamePasswordAuthenticationToken) principal).getPrincipal();

        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPassword()))  //user.getPassword() is encoded and the other is raw that we got now that is the current password asked from the user for changing. 
            throw new IllegalStateException("Wrong password.");

        if (!request.getNewPassword().equals(request.getConfirmationPassword()))
            throw new IllegalStateException("Password mismatch.");

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
    }

    @Override
    public RegisterResponse deleteUser(Long userId) {
        userRepository.deleteById(userId);
        return RegisterResponse.builder().message("User Deleted Successfully").build();
    }

    @Override
    public List<User> getAll() {
        return userRepository.findAll();
    }

    @Override
    public UserDto getUserDetailsByEmail(String email) {
        Optional<User> optionalUser = userRepository.findByEmail(email);
        System.out.println(optionalUser);
        User user = optionalUser.orElseThrow(() ->
        new UserNotFoundException("User not found with email: " + email));
        return UserDto.builder()
        .id(user.getId())
        .name(user.getName())
        .email(user.getEmail())
        .password(user.getPassword())
        .age(user.getAge())
        .role(user.getRole())
        .build();
    }
}
