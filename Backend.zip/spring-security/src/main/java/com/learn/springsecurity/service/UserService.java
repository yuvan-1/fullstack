package com.learn.springsecurity.service;

import java.security.Principal;
import java.util.List;

import com.learn.springsecurity.dto.common.UserDto;
import com.learn.springsecurity.dto.request.PasswordRequest;
import com.learn.springsecurity.dto.response.RegisterResponse;
import com.learn.springsecurity.model.User;

public interface UserService {

    void forgotPassword(PasswordRequest request, Principal principal);

    RegisterResponse deleteUser(Long userId);

    List<User> getAll();

    UserDto getUserDetailsByEmail(String name);

}
