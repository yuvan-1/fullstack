package com.learn.springsecurity.model;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="_loan_types")
public class LoanTypes {
    
         @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)    
    private Long LoanId;

    private String loan_title;

    private String scheme;

    private String description;

    private String objective;

    private String eligibility;

    private String loan_amount;

    private String repayment_period;
    
    private String rate_of_interest;
    
    private String service_charge;


    //This relationship is useful if you often need to access all applications associated with a particular loan type directly from the LoanTypes entity. It allows for easier navigation from a loan type to its collection of applications.
    @Default
    @OneToMany(mappedBy = "loanType", cascade = CascadeType.ALL)
    private Set<Application> applicationDetails = new HashSet<>();
}

