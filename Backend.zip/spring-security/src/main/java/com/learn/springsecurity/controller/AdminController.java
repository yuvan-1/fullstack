package com.learn.springsecurity.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learn.springsecurity.dto.response.RegisterResponse;
import com.learn.springsecurity.model.User;
import com.learn.springsecurity.service.UserService;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping("/api/v1/admin")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")  //only authenticated users with the 'ADMIN' role can access the endpoints defined in this controller. This provides a layer of security at the class level.
@Tag(name = "Admin")  //This is used by Swagger/OpenAPI to group all endpoints in this controller under the "Admin" tag in the API documentation.
public class AdminController {


    private final UserService userService;

    @GetMapping
    @PreAuthorize("hasAuthority('admin:read')")  // annotation ensures that only users with the 'admin:read' authority can access this endpoint.
    public String get() {
        return "GET:: admin controller";
    }

    @PostMapping
    @PreAuthorize("hasAuthority('admin:create')")  //access to users with 'admin:create' authority. This endpoint is marked as @Hidden, meaning it will not appear in the Swagger/OpenAPI documentation. It returns a string message indicating a create operation.
    @Hidden
    public String post() {
        return "POST:: admin controller";
    }

    @PutMapping
    @PreAuthorize("hasAuthority('admin:update')")
    @Hidden
    public String put() {
        return "PUT:: admin controller";
    }

    @DeleteMapping
    @PreAuthorize("hasAuthority('admin:delete')")
    @Hidden
    public String delete() {
        return "DELETE:: admin controller";
    }

    @DeleteMapping("/delete/{userId}")
    @PreAuthorize("hasAuthority('admin:delete')")
    // @Hidden
    public ResponseEntity<?> deleteById(@PathVariable("userId") Long userId) {
        RegisterResponse reponse = new RegisterResponse();
        try {
            reponse = userService.deleteUser(userId);
            return new ResponseEntity<>(reponse, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }

    @GetMapping("/getAll")
    @PreAuthorize("hasAuthority('admin')")
    public ResponseEntity<List<User>> getAllUser() {
        List<User> users = userService.getAll();
        return ResponseEntity.ok(users);
    }
    
    
}


//@PreAuthorize annotation can be used to enforce method-level security based on roles and authorities within a Spring Boot application

// The use of @Hidden on certain methods suggests that the developer intends to restrict the visibility of some administrative actions in the generated API documentation, likely for security reasons.