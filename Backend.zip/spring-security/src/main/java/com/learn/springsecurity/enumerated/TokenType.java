package com.learn.springsecurity.enumerated;

public enum TokenType {
    BEARER
}
