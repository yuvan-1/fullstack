// import React from "react";
import HomeScreen from "./Home";
import "../assets/css/menu.css";
import "../assets/css/About.css";
import aboutimg from "../assets/images/aboutimg.svg";
import "../../src/pages/Footer";
import Footer from "../../src/pages/Footer";
import abtlogo1 from "../assets/images/logoabt1.svg"
import abtlogo2 from "../assets/images/logoabt2.svg"
import abtlogo3 from "../assets/images/logoabt3.svg"



// import * as React from 'react';
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import BoltIcon from "@mui/icons-material/Bolt";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import InstallMobileOutlinedIcon from "@mui/icons-material/InstallMobileOutlined";
import EditNoteIcon from "@mui/icons-material/EditNote";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import DevicesIcon from "@mui/icons-material/Devices";
import GpsFixedIcon from "@mui/icons-material/GpsFixed";
import SpeedIcon from '@mui/icons-material/Speed';

const About = () => {
  return (
    <div className="abt">
      <div className="na">
        <HomeScreen />
      </div>
      <div className="bo">
        <br />
        <div className="content-container">
          <div className="text-left">
            <h1>
              <u>The Initiative</u>
            </h1>
            <br></br>
            <br></br>
            <p>
              psbloansin59minutes.com is a new-age digital lending platform. the
              platform has been developed with an objective to provide advanced
              technology-based financial innovations and solutions psb59
              platform was born from the insight that MSMEs found it hard to
              avail loans from formal banking channels due to the tedious
              application, documentation and verification processes.
              <br />
              <br />
              powered by rigorous innovation and technological advancements,
              we’re proud to be recognized as india’s largest lending platform
              (by credit suisse in march 2019).
              <br />
              <br />
              we passionately serve our customers with cutting-edge financial
              products and strive to help them pursue their dreams. the platform
              integrates advanced technologies like AI and ML to automate and
              digitize the lending processes for borrowers and lenders.
              <br />
              <br />
              speed and simplicity of availing loans have perennially been pain
              points for the indian borrower. this is where our platform makes
              the lives of any borrower easy and smooth.
            </p>
          </div>
          <div className="right-image">
            <img src={aboutimg} alt="Description of the image" />
          </div>

          <div className="abtcenter">
            <h1>
              How Agro Funds loans in 15 minutes changed the borrower<br></br>
              journey for the better
            </h1>
          </div>
          <div className="abtcards">
          <Card sx={{ maxWidth: 300, boxShadow: '2px 8px 20px rgba(0, 0, 0, 0.8)' }}>              <CardActionArea>
                <CardMedia
                  component="img"
                  height="160"
                  image={abtlogo1}
                  alt="green iguana"
                />
                <CardContent>
                  <Typography
                    gutterBottom
                    variant="h4"
                    component="div"
                    fontSize={28}
                  >
                    Intelligent use of Technology
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    the platform uses sophisticated algorithms to read and
                    analyses data points from various sources such as IT
                    returns, GST data, bank statements, MCA21, bureau, etc.
                    while capturing the applicant’s basic details using smart
                    analytics.
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>

            <Card sx={{ maxWidth: 300, boxShadow: '2px 8px 20px rgba(0, 0, 0, 0.8)' }}>              <CardActionArea>
                <CardMedia
                  component="img"
                  height="160"
                  image={abtlogo2}
                  alt="green iguana"
                />
                <CardContent>
                  <Typography
                    gutterBottom
                    variant="h4"
                    fontSize={28}
                    component="div"
                  >
                    fast application process
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    As the name suggests, the platform has created a new
                    benchmark by providing digital approvals for business as
                    well as retail loans within 15 minutes.
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>

            <Card sx={{ maxWidth: 300, boxShadow: '2px 8px 20px rgba(0, 0, 0, 0.8)' }}>              <CardActionArea>
                <CardMedia
                  component="img"
                  height="160"
                  image={abtlogo3}
                  alt="green iguana"
                />
                <CardContent>
                  <Typography
                    gutterBottom
                    variant="h4"
                    fontSize={28}
                    component="div"
                  >
                    Loans from anywhere, anytime
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    the user-friendly platform offers a contactless journey
                    where a borrower can apply for business loan or retails
                    loans with multiple banks at one go without vising banks
                    from anywhere anytime.
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          </div>

          <div className="abtcenter">
            <h1>Redefining customer experience using modern technology</h1>
          </div>

          <div className="allicondets">
            <div className="icondets">
              <BoltIcon style={{ fontSize: "60" }} />
              <br></br>
              <p>faster digital approval in 59 minutes</p>
            </div>

            <div className="icondets">
              <SettingsOutlinedIcon style={{ fontSize: "60" }} />
              <br></br>
              <p>digital application from anywhere anytime</p>
            </div>

            <div className="icondets">
              <InstallMobileOutlinedIcon style={{ fontSize: "60" }} />
              <br></br>
              <p>contactless and hassle-free application</p>
            </div>

            <div className="icondets">
              <EditNoteIcon style={{ fontSize: "60" }} />
              <br></br>
              <p>one form for all the lenders on the platform</p>
            </div>
            <br></br>
          </div>
          <div className="allicondets">
            <div className="icondets">
              <CalendarMonthIcon style={{ fontSize: "60" }} />
              <br></br>
              <p>sanction and disbursement expected within 7-10 working days</p>
            </div>

            <div className="icondets">
              <DevicesIcon style={{ fontSize: "60" }} />
              <br></br>
              <p>
                empowered to choose preferred lender products from multiple loan
                offers
              </p>
            </div>

            <div className="icondets">
              <GpsFixedIcon style={{ fontSize: "60" }} />
              <br></br>
              <p>real time tracking of <br></br>applications online</p>
            </div>
          </div>
        </div>
        {/* <Divider
          style={{ marginLeft: "13%", marginRight: "13%", marginTop: "3%" }}
        /> */}
        <Footer />
      </div>
    </div>
  );
};

export default About;
