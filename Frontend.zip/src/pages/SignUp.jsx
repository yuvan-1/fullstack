import { Button } from "@mui/material";
import axios from "axios";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../assets/css/SignUp.css";

const SignUp = () => {
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const Navigate=useNavigate();
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { username, email, password, confirmPassword } = formData;
    console.log(formData);
    
    const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z\d]{8,}$/;
    if (password !== confirmPassword) {
     window.alert("Passwords do not match.");
     return;
   }
    if (!passwordRegex.test(password)) {
      window.alert("Password must contain at least 8 characters with at least one uppercase letter, one lowercase letter, and one number.");
      return;
    }
    
    
    try {
      const response = await axios.post(
        "http://localhost:8181/api/v1/auth/register",
        {
          name: username,
          email: email,
          password: password,
          role:"USER"
        }
      );
      Navigate("/login")
      console.log("Success");
      console.log("API response:", response.data);
      // Handle successful response
      
    } catch (error) {
      if (error.response.status === 403) {
        console.log("Error: Forbidden (403)");
        // Handle 403 error
      } else {
        console.error("Error:", error);
        // Handle other errors
      }
    }
  };

  return (
    <div className="lo1">
      <div className="brand2">
        <h1>Agro Funds</h1>
        <h4>pvt Limited</h4>
      </div>
      <div className="container1">
        <div className="signup-form">
          <h2 style={{ color: "white" }}>
            <center>Sign Up</center>
          </h2>
          <form onSubmit={handleSubmit}>
            <div className="form-group1">
              <label htmlFor="username">Username:</label>
              <input
                type="text"
                id="username"
                name="username"
                value={formData.username}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group1">
              <label htmlFor="email">Email:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group1">
              <label htmlFor="password">Password:</label>
              <input
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group1">
              <label htmlFor="confirmPassword">Confirm Password:</label>
              <input
                type="password"
                id="confirmPassword"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                required
              />
            </div>
            <Button
              type="submit"
              variant="contained"
              style={{ backgroundColor: "white", color: "black" }}
            >
              Sign Up
            </Button>
          </form>
          <div className="login1-link">
            <br></br>
            Already have an account? <Link to="/login">Login</Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
