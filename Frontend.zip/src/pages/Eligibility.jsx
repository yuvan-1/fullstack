import React from "react";
import Footer from "../../src/pages/Footer";
import "../assets/css/Eli.css";
import "../assets/css/menu.css";
import HomeScreen from "./Home";

const Eligibility = () => {
  return (
    <div>
      <div className="na">
        <HomeScreen />
      </div>
      <div className="bo">
        <div className="loaneligible">
        <h1>What is a Loan Against Agricultural Land?</h1>
          <br></br>
          <p style={{ fontSize: "22px" }}>
            If a farmer has a piece of land in his/her name, that can be used as
            a collateral to obtain a loan from a bank or a financial
            institution. When a borrower pledges an agricultural land for money
            it is called as "Loan Against Agricultural Land" or "Agriculture
            Loan".
          </p>
          <br></br>
          <br></br>


          <h1>Loan Against Agricultural Land</h1>
          <br></br>
          <p style={{ fontSize: "22px" }}>
            Farmers in India incur massive expenses while cultivating crops.
            Most of the time, they barely make profits and struggle to repay
            their debts. We have heard the cries of the agriculturists in India
            lamenting about the low prices they get on their produce, the high
            cost of manure, and lack of water.<br></br>
            <br></br> To continue farming, they land up borrowing from private
            lenders who charge a very high rate of interest which makes things
            worse. To help farmers in India by offering them financial aid when
            required, many banks in India offer agriculture loans.
          </p>
          
          <br></br>
          <br></br>
          <h1>Features of Loan On Agricultural Land</h1>
          <br></br>
          <li>
            Loan Against Agricultural Land is specially designed for people who
            cultivate crops like farmers, planters, or Horticulturists. It
            cannot be availed by a businessman or a professional.
          </li>{" "}
          <br></br>
          <li>
            Usually, the farmer does not have to furnish Income Tax Returns to
            apply for this type of loan.
          </li>{" "}
          <br></br>
          <li>It requires minimum documentation.</li>
          <br></br>
          <li>The loan tenure goes up to 20 years with many banks.</li>{" "}
          <br></br>
          <li>There are no hidden charges on Agriculture Loans.</li> <br></br>
          <li>
            The lender usually works out a flexible repayment plan considering
            the farmer's situation.
          </li>{" "}
          <br></br>
          <li>
            The turnaround time is fast and the banks are sensitive to the
            harvest season.
          </li>{" "}
          <br></br>
          <li>
            The borrower can use the funds for agricultural purposes like food
            processing, buy an agricultural equipment, set up dairy
            units/fisheries/rice mills, or for micro-irrigation.
          </li>{" "}
          <br></br>
          <li>
            They can also use the funds to set up a greenhouse, cold storage, or
            a horticulture centre.
          </li>{" "}
          <br></br>
          <li>
            To buy agriculture insurance to protect from crop losses.
          </li>{" "}
          <br></br>
          <li>
            You can use the funds to buy livestock or cover your marketing and
            operating expenses.
          </li>{" "}
          <br></br>
          <br></br>
          <h1>Eligibility Criteria for Loan Against Agricultural Land</h1><br></br>
          <li>
            Farmers, Dairy Owners, Horticulturists, and any Orchard owners are
            eligible to apply for an Agriculture Loan.
          </li>{" "}
          <br></br>
          <li>
            Most lenders prefer the age of the applicant to be within 24 to 65
            years of age. However, there are few banks who offer loans to
            applicants are 18 years of age. The eligibility differs from one
            bank to another.
          </li>{" "}
          <br></br>
          <li>
            If the land is owned by two people, co-applicant is mandatory.
          </li>{" "}
          <br></br>
          <li>
            A agricultural land is pledged as a collateral. The borrower should
            have clear titles to the land to be eligible to apply for a Loan
            Against Agricultural Land.
          </li>{" "}
          <br></br>
          <li>
            Usually, lenders prefer borrowers to have residence stability of 2
            years.
          </li>{" "}
          <br></br>
          <li>
            Most banks offer loans based on the size of the land pledged. They
            usually mention the minimum acres of land a farmer should have to
            apply for a loan.
          </li>{" "}
          <br></br> <br></br>
        </div>

        <Footer />
      </div>
    </div>
  );
};

export default Eligibility;


