// import { default as React, default as React } from 'react';
import {
  Button,
  TextField,
  Typography
} from "@mui/material";
import Avatar from '@mui/material/Avatar';
import axios from "axios";
import { useEffect, useState } from "react";

// import { Button } from "bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from 'react-router-dom';
import "../assets/css/Profile.css";
import { addUserData } from "../config/GlobalSlice";
import Footer from "./Footer";
import HomeScreen from "./Home";

const Profile = () => {
  const Navigate= useNavigate();
  const editProfile=()=>
  {
    Navigate("/edit")
  }
  const [users, setUsers] = useState([]);
  const dispatch = useDispatch();
  
  // const location = useLocation();

  useEffect(() => {
    // Fetch user data from backend
    fetchUsers();
  }, []);
 

  const { token, userData } = useSelector((state) => state.global);

  const fetchUsers = async () => {
    try {
      const response = await axios.get(
        "http://localhost:8181/api/v1/user/details",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const data = response.data;
      console.log(response);
      setUsers(data);
      dispatch(addUserData(response.data));
      console.log(userData);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };


  return (
   <div>
      <div className="na">
        <HomeScreen />
      </div>

      <h2>User Profile</h2>
      <div className="con">
  <div className="ac">
        <Avatar sx={{ width: '130px', height: '130px', marginRight: '30%', marginLeft: '10%' }} />
        <Button style={{paddingLeft:'18%'}} onClick={editProfile}>Edit Avatar</Button>
        </div>
<div className="f">

            <div className="r">
            <Typography variant="h6">{userData.name}</Typography>
            <Typography>Name: <TextField value={userData.name}  /></Typography>
            <Typography>Email: <TextField value={userData.email}  /></Typography>
            </div>

          <div className="r">
    
            <Typography>User ID: <TextField value={userData.id} disabled /></Typography>
            <Typography>Age: <TextField value={userData.age} disabled /></Typography>
            <Typography>Mobile No: <TextField value={userData.mobileNo} disabled /></Typography>
            </div>

            <div className="r">
            <Typography>Gender: <TextField value={userData.gender} disabled /></Typography>
            <Typography>Marital Status: <TextField value={userData.maritalStatus} disabled /></Typography>
            <Typography>Address Line 1: <TextField value={userData.addressLine1} disabled /></Typography>
            </div>

            <div className="r">
            <Typography>Address Line 2: <TextField value={userData.addressLine2} disabled /></Typography>
            <Typography>City: <TextField value={userData.city} disabled /></Typography>
            <Typography>State: <TextField value={userData.state} disabled /></Typography>
            </div>
            <div className="r">
            <Typography>Nationality: <TextField value={userData.nationality} disabled /></Typography>
            <Typography>Country: <TextField value={userData.country} disabled /></Typography>
            <Typography>Pincode: <TextField value={userData.pincode} disabled /></Typography>
            </div>
          </div>
       
        </div>
      
       
    
      <div style={{ maxHeight: '100vh', display: 'grid',marginTop:'14.2%', gridTemplateRows: 'auto 1fr auto' }}>

  <Footer />
</div>
</div>

  );
};

export default Profile;
