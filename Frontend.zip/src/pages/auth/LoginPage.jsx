import { Button } from "@mui/material";
import axios from "axios";
import { useState } from "react";
import { useDispatch } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import "../../assets/css/LoginPage.css";
import { addToken, toggleLogin } from "../../config/GlobalSlice";

const LoginPage = ({ setLoginStatus }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleLogin = async () => {
    try {
      const response = await axios.post("http://localhost:8181/api/v1/auth/login", {
        email: email,
        password: password,
      });
      console.log(response);

      const token = response.data.access_token;
      console.log(token);
      if(response.status === 202){
        dispatch(toggleLogin(true));
        dispatch(addToken(token));
    
        navigate("/land");
      }
      
    } catch (error) {
      window.alert("User Not Found", error);
    }
  };

  return (
    <div className="lo">
      <div className="brand">
        <h1>Agro Funds</h1>
        <h3>pvt limimted</h3>
      </div>
      <div className="container">
        <form className="login-form">
          <h1>Login</h1>
          <div className="input-group">
            <label htmlFor="username">Email</label>
            <input
              type="text"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="input-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <center>
            <Button
              type="button"
              disabled={!email || !password}
              onClick={handleLogin}
              style={{ backgroundColor: "white", color: "black" }}
            >
              Login
            </Button>
          </center>
          <br />
          <div>
            Don't have an account?{" "}
            <Link style={{ color: "white", textDecoration: "none" }} to="/sig">
              Sign Up
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;
