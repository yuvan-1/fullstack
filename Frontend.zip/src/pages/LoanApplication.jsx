import React from 'react'

const LoanApplication = () => {
  return (
    <div>
      <h1>HERE I WILL CREATE THE LOAN APPLICATION FOMR</h1>
    </div>
  )
}

export default LoanApplication
