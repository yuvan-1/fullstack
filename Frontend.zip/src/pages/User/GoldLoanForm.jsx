import React, { useState } from 'react';
import "../../assets/css/GoldLoanForm.css";

const GoldLoanForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    cropDetails: '',
    goldWeight: '',
    loanAmount: '',
    dob: '',
    maritalStatus: '',
    farmerId: '',
    annualIncome: '',
    emiInterest: ''
  });
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
    console.log(formData);
    
    // Display loading spinner
    setSubmitting(true);

    // Simulate asynchronous submission
    setTimeout(() => {
      // Reset form data
      setFormData({
        name: '',
        address: '',
        cropDetails: '',
        goldWeight: '',
        loanAmount: '',
        dob: '',
        maritalStatus: '',
        farmerId: '',
        annualIncome: '',
        emiInterest: ''
      });

      // Hide loading spinner and show success message
      setSubmitting(false);
      window.alert("Your Application is successful");
    }, 4000); // Simulating a 2-second delay
  };

  return (
    <div className="agricultural-gold-loan-form-container">
      <h2>Agricultural Gold Loan Application Form</h2>
      <form onSubmit={handleSubmit}>
        <label>Name:</label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
        />
        <label>Father/Spouse Name:</label>
        <input
          type="text"
          name="fatherSpouseName"
          value={formData.fatherSpouseName}
          onChange={handleChange}
        />

        <label>Mother Name:</label>
        <input
          type="text"
          name="motherName"
          value={formData.motherName}
          onChange={handleChange}
        />

        <label>Date of Birth:</label>
        <input
          type="date"
          name="dob"
          value={formData.dob}
          onChange={handleChange}
        />

        <label>Martial status:</label>
        <select
          name="maritalStatus"
          value={formData.maritalStatus}
          onChange={handleChange}
        >
          <option value="single">Single</option>
          <option value="married">Married</option>
          <option value="divorced">Divorced</option>
          <option value="widowed">Widowed</option>
        </select>

        <label>PAN Number:</label>
        <input
          type="number"
          name="panNumber"
          value={formData.panNumber}
          onChange={handleChange}
        />

        <label>Education:</label>
        <input
          type="text"
          name="education"
          value={formData.education}
          onChange={handleChange}
        />

        <label>Farmer Id:</label>
        <input
          type="number"
          name="farmerId"
          value={formData.farmerId}
          onChange={handleChange}
        />

        <label>Annual Income:</label>
        <input
          type="number"
          name="annualIncome"
          value={formData.annualIncome}
          onChange={handleChange}
        />

        <label>EMI/Interest:</label>
        <input
          type="number"
          name="emiInterest"
          value={formData.emiInterest}
          onChange={handleChange}
        />

        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default GoldLoanForm;
