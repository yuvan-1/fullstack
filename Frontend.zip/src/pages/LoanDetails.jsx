// MultiActionAreaCard.js

import { Button, CardActionArea, CardActions } from '@mui/material';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import React from 'react';
import { useNavigate } from 'react-router-dom';
import "../assets/css/LoanDetails.css";
import Horticulture from "../assets/images/Horticulture.jpg";
import cattleloan from "../assets/images/cattleloan.jpg";
import croploan from "../assets/images/croploan.jpg";
import goldloan from "../assets/images/goldloan.webp";
import landloan from "../assets/images/landloan.jpg";
import machineloan from "../assets/images/machineloan.avif";
import Footer from './Footer';
import HomeScreen from './Home';

export default function MultiActionAreaCard() {

  const navigate=useNavigate();

  const handleApplyGoldLoan=()=>{
    navigate('/goldloan');
  }
  const handleApplyLoan=()=>{
    navigate('/applyloan');
  }
  return (
    <React.Fragment>
      <div className="na">
        <HomeScreen/>
      </div>
      <div className="bo">
      <div className='allcards'>
      <Card className="loancards"  style={{ boxShadow: '16px 16px 16px rgba(0, 0, 0, 0.9)',borderRadius:'20px' }}>
        <CardActionArea>
          <CardMedia
            component="img"
            height="220"
            image={croploan}
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Crop Loan
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over 6,000
              species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
        </CardActionArea>
        <CardActions>
          <Button size="large" color="primary" onClick={handleApplyLoan}>
            Apply
          </Button>
        </CardActions>
      </Card>

      <Card className="loancards"  style={{ boxShadow: '16px 16px 16px rgba(0, 0, 0, 0.9)',borderRadius:'20px' }}>
        <CardActionArea>
          <CardMedia
            component="img"
            height="220"
            image={goldloan}
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Gold Loan
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over 6,000
              species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
        </CardActionArea>
        <CardActions>
          <Button size="large" color="primary" onClick={handleApplyGoldLoan}>
            Apply
          </Button>
        </CardActions>
      </Card>

      <Card className="loancards"  style={{ boxShadow: '16px 16px 16px rgba(0, 0, 0, 0.9)',borderRadius:'20px' }}>
        <CardActionArea>
          <CardMedia
            component="img"
            height="220"
            image={machineloan}
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Machine Loan
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over 6,000
              species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
        </CardActionArea>
        <CardActions>
          <Button size="large" color="primary" onClick={handleApplyLoan}>
            Apply
          </Button>
        </CardActions>
      </Card>
      </div>

      <div className="cardscol">
        
      <Card className="loancards"  style={{ boxShadow: '16px 16px 16px rgba(0, 0, 0, 0.9)',borderRadius:'20px' }}>
        <CardActionArea>
          <CardMedia
            component="img"
            height="220"
            image={Horticulture}
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Horticultural Loan
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over 6,000
              species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
        </CardActionArea>
        <CardActions>
          <Button size="large" color="primary" onClick={handleApplyLoan}>
            Apply
          </Button>
        </CardActions>
      </Card>

      
      <Card className="loancards"  style={{ boxShadow: '16px 16px 16px rgba(0, 0, 0, 0.9)',borderRadius:'20px' }}>
        <CardActionArea>
          <CardMedia
            component="img"
            height="220"
            image={cattleloan}
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Livestock Loan
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over 6,000
              species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
        </CardActionArea>
        <CardActions>
          <Button size="large" color="primary" onClick={handleApplyLoan}>
            Apply
          </Button>
        </CardActions>
      </Card>

      
      <Card className="loancards"  style={{ boxShadow: '16px 16px 16px rgba(0, 0, 0, 0.9)', borderRadius:'20px'}}>
        <CardActionArea>
          <CardMedia
            component="img"
            height="220"
            image={landloan}
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Land Purchase Loan
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over 6,000
              species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
        </CardActionArea>
        <CardActions>
          <Button size="large" color="primary" onClick={handleApplyLoan}>
            Apply
          </Button>
        </CardActions>
      </Card>

      </div>
      <Footer/>
    </div>
    </React.Fragment>
  );
}
