
import "../Footer"
// import Footer from './../Footer';
import "../../pages/SideBar"
import AdminSideBar from "../../pages/SideBar"

const AdminSide = () => {
  return (
    <div>
      
      <AdminSideBar/>
      <h1>VAaa da admin uhhhhh...... </h1> 
    </div>
  )
}

export default AdminSide
