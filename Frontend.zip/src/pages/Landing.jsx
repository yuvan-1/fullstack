import { Divider } from "@mui/material";
import React from "react";
import { useNavigate } from "react-router-dom";
import "../../src/pages/Footer";
import Footer from "../../src/pages/Footer";
import "../assets/css/Land.css";
import aaa from "../assets/images/aaa.png";
import loandetails from "../assets/images/loandetails.png";
import HomeScreen from "./Home";

const Landing = () => {
  const navigate = useNavigate();

  const handleApply = () => {
    navigate("/loandetails");
  };
  return (
    <div className="container4">
      {/* <div className="landing-container"> */}
      <div className="na">
        <HomeScreen />
      </div>
      <div className="bo">
        <div className="landcontainer">
          <div className="landleft">
            Empowering farmers to grow their dreams.
            <br></br>
            <br></br>
            <br></br>
            we are online marketplace to cater to various financial aspirations
            of individuals and businesses in a simple, quick & hassle-free way.
          </div>

          <div className="landright">
            <img src={aaa} />
          </div>
        </div>
        <div className="back">
          <div className="paragraph-container">
            <div>
              Welcome to Agro Funds, where we cultivate opportunities through
              tailored agriculture loans. <br></br>
              <br></br>
              when money is need of the hour, we’ll help you get it, in less
              than an hour.
            </div>
            <br></br>
            {/* <div>
                No document charges applied..
              </div> */}
          </div>
        </div>
        <div className="allspecs">
          <div className="specs">
            <h1>21 +</h1>
            <p>partner banks</p>
            {/* <div>6 Lac +</div>
            <div>71,000 cr. +</div>
            <div>5,000 +</div> */}
          </div>

          <div className="specs">
            <h1>6 lac +</h1>
            <p>journeys completed</p>
          </div>

          <div className="specs">
            <h1>71,000 cr. +</h1>
            <p>loans disbursed</p>
          </div>

          <div className="specs">
            <h1>5,000 +</h1>
            <p>video testimonials</p>
          </div>
        </div>
        <Divider
          style={{ marginLeft: "13%", marginRight: "13%", marginTop: "3%" }}
        />

        <div className="format">
          <h1>Get Agri Loan approval in 15 minutes</h1>
          <br></br>
          <h3>avail loans upto 10 lakhs.</h3>
        </div>

        <div className="overlay-image">
          <img src={loandetails} alt="Your image" />
        </div>

        <div class="textformat">
          <h1>
            Apply online for an agriculture loan to fuel your farming ambitions.
            Our streamlined web application process ensures convenience and
            efficiency, empowering you to secure the funds needed for equipment,
            land, and operational expenses with ease.
          </h1>
        </div>
        <div className="apply">
        <div className="applybut">
        <button type="button" onClick={handleApply} style={{cursor:'pointer'}}>
          Apply Now
        </button>
        </div>
        </div>

        <br></br>
        <br></br>
      <Footer/>
      </div>
    </div>
  );
};

export default Landing;
