import React, { Suspense } from "react";

import { Route, Routes } from "react-router-dom";
import AdminSide from "./pages/Admin/AdminSide";
import Landing from "./pages/Landing";
import Loader from "./pages/Loader";
import LoanApplication from "./pages/LoanApplication";
import LoanDetails from "./pages/LoanDetails";
import EditProfile from "./pages/User/EditProfile";
import GoldLoanForm from "./pages/User/GoldLoanForm";

const LoginPage = React.lazy(() => import("./pages/auth/LoginPage"));
const SignUp = React.lazy(() => import("./pages/SignUp"));
const NavBar = React.lazy(() => import("./pages/Home"));
const Profile = React.lazy(() => import("./pages/Profile"));
const About = React.lazy(() => import("./pages/About"));
const Eligibility = React.lazy(() => import("./pages/Eligibility"));

function App() {
  return (
    <Routes>
      <Route
        path="/"
        element={
          <Suspense fallback={<Loader />}>
            <SignUp />
          </Suspense>
        }
      />
      <Route
        path="/login"
        element={
          <Suspense fallback={<Loader />}>
            <LoginPage />
          </Suspense>
        }
      />
      <Route
        path="/sig"
        element={
          <Suspense fallback={<Loader />}>
            <SignUp />
          </Suspense>
        }
      />
      <Route
        path="/nav"
        element={
          <Suspense fallback={<Loader />}>
            <NavBar />
          </Suspense>
        }
      />
      <Route
        path="/pro"
        element={
          <Suspense fallback={<Loader />}>
            <Profile />
          </Suspense>
        }
      />
      <Route
        path="/abt"
        element={
          <Suspense fallback={<Loader />}>
            <About />
          </Suspense>
        }
      />
      <Route
        path="/eli"
        element={
          <Suspense fallback={<Loader />}>
            <Eligibility />
          </Suspense>
        }
      />
      <Route
        path="/land"
        element={
          <Suspense fallback={<Loader />}>
            <Landing />
          </Suspense>
        }
      />
       <Route
        path="/edit"
        element={
          <Suspense fallback={<Loader/>}>
            <EditProfile />
          </Suspense>
        }
      />
      <Route
        path="/loandetails"
        element={
          <Suspense fallback={<Loader />}>
            <LoanDetails />
          </Suspense>
        }
      />
      <Route
        path="/applyloan"
        element={
          <Suspense fallback={<Loader />}>
            <LoanApplication />
          </Suspense>
        }
      />
      <Route
        path="/adminhome"
        element={
          <Suspense fallback={<Loader />}>
            <AdminSide />
          </Suspense>
        }
      />
      <Route
        path="/goldloan"
        element={
          <Suspense fallback={<Loader />}>
            <GoldLoanForm />
          </Suspense>
        }
      />
    </Routes>
    // <div>
    //   <HomePage/>
    // </div>
  );
}

export default App;
