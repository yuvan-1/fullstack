import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  isLoggedIn: false,
  token: null,
  userData: null
};

const globalSlice = createSlice({
  name: "Global",
  initialState,
  reducers: {
    toggleLogin: (state, action) => {
      state.isLoggedIn = action.payload;
    },
    addToken: (state, action) => {
      state.token = action.payload;
    },
    delToken: (state, action) => {
      state.token = null;
    },
    addUserData: (state, action) => {
      state.userData = action.payload;
    },
    delDelUserData: (state, action) => {
      state.userData = null;
    },
  },
});

export const { toggleLogin, addToken, delToken, addUserData, delDelUserData } = globalSlice.actions;

export default globalSlice.reducer;
